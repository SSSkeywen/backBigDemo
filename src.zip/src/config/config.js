const config = {
    api_address_url: 'https://tpwxtestcloud.life.cntaiping.com/'
}
export { config }
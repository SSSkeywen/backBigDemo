export function interestRate(rate) {
    return (rate*100).toFixed(2) + '%';  
}
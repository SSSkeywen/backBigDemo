const apiConfig = {
    api_base_url: 'nwxqhb/api/v2/',
    
}
export { apiConfig }